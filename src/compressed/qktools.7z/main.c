/*
VERSION .01 'QKTMP' CROSS TOOLCHAIN BUILD TOOL.
This program is property of the Unix Underground Corporation. 
This program is proprietary software protected under the terms of the "Unix Underground General Availibility License." 
Employees of Unix Underground Corporation may access, compile and modify this code but may not redistribute any version of this code to the general public or other outside entity. 
Nor may an employee of Unix Underground Corporation compile this code into an executable to be distributed to the general public or any other outside entity.
For more details on the terms of working with Unix Underground proprietary software please reference Document #UU-GA-01
$RTW:01022014
*/

#include <string.h>
#include <stdio.h>

int main(int argc, char argv[]) 
{

printf("Welcome to the Unix Underground Build Tool. This program is protected under the terms of the Unix Underground General Availibility License and may only be used by authorized employees.");
		
printf("\nPlease wait while I run filesystem checks...");
printf("\nI am ready to deploy the build environment. \nPlease enter the root directory of the build environment:");



return 0;
}
