#include <signal.h>
int
mksh_cfg= SIGSTKSZ
;
